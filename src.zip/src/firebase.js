
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
export const firebaseConfig = {
    apiKey: "AIzaSyAJcVUamjo3y8nOULM_QEHYN9HqKT0DjDs",
    authDomain: "honey-clone-da910.firebaseapp.com",
    databaseURL: "https://honey-clone-da910-default-rtdb.firebaseio.com",
    projectId: "honey-clone-da910",
    storageBucket: "honey-clone-da910.appspot.com",
    messagingSenderId: "566711327145",
    appId: "1:566711327145:web:96193434f93d09810cccb8"
  };