import React, { useState } from "react";
import { Col, Container,Row} from "react-bootstrap";
import { useDispatch } from "react-redux";
import { logoutIntiate } from "../../redux/actions/loginRegisterActions";
import { Calender } from "./Calender";
import { PerformanceChart } from "./PerformanceChart";
export const DashBoard = () => {
  const dispatch = useDispatch();
  
  const handleLogout=()=>{
    console.log("in handle logout");
    dispatch(logoutIntiate());
  }
  return (
    <>
      <button onClick={handleLogout}>Logout</button>
      <Container>
          <Row>
              <Col xs={12} md={4}><Calender/></Col>
              <Col xs={12} md={8}><PerformanceChart/></Col>
          </Row>
      </Container>
      
    </>
  );

}
